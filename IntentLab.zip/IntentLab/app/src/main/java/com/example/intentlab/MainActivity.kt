package com.example.intentlab

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar

class MainActivity<Button : View?> : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val username = findViewById<EditText>(R.id.edt_username)
        val password = findViewById<EditText>(R.id.edt_password)
        val btnLogin = findViewById<Button>(R.id.btn_login)

        btnLogin?.setOnClickListener{
            if(username.text.toString().equals("admin")
                && password.text.toString().equals("admin")){
                val intent = Intent(this, HomeActivity:: class.java)
                val msg = intent.putExtra("name", username.text.toString())
                startActivity(intent)
            } else {
                val snackbar = Snackbar.make(it, "incorrect username or password",
                    Snackbar.LENGTH_SHORT).setAction("Action", null)
                snackbar.show()
            }
        }
    }
}

