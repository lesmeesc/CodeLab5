package com.example.intentlab

import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.navigation.NavigationView
import android.os.Bundle
import android.os.PersistableBundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.FragmentTransaction
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.app_bar_main.*

class HomeActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener{
    lateinit var drawer: DrawerLayout
    lateinit var toggle:ActionBarDrawerToggle
    lateinit var homeFragment: HomeFragment
    lateinit var galleryFragment: GalleryFragment
    lateinit var aboutFragment: AboutFragment


    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        val toolbar = findViewById<Toolbar>(R.id.toolbar_main)

        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.title = "UCJaguar App"

        drawer = findViewById(R.id.drawer_layout)

        toggle =  ActionBarDrawerToggle(this, drawer, toolbar,
           R.string.navigation_drawer_open,
            R.string.navigation_drawer_close)

        toggle.isDrawerIndicatorEnabled=true
        drawer.addDrawerListener(toggle)
        toggle.syncState()
        supportActionBar?.setHomeButtonEnabled(true)

        navigation_view.setNavigationItemSelectedListener(this)
    }

    override fun onPostCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        toggle.syncState()
        super.onPostCreate(savedInstanceState, persistentState)
    }
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        toggle.onConfigurationChanged(newConfig)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (toggle.onOptionsItemSelected(item))
            return true
        return super.onOptionsItemSelected(item)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
      when (item.itemId){
          R.id.navi_home ->{
              Toast.makeText(this, "clicked home", Toast.LENGTH_SHORT).show()
              homeFragment = HomeFragment()
              supportFragmentManager
                  .beginTransaction()
                  .replace(R.id.content_frame, homeFragment)
                  .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                  .commit()
          }
          R.id.navi_gallery ->{
              Toast.makeText(this, "clicked gallery", Toast.LENGTH_SHORT).show()
              galleryFragment = GalleryFragment()
              supportFragmentManager
                  .beginTransaction()
                  .replace(R.id.content_frame, galleryFragment)
                  .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                  .commit()
          }
          R.id.navi_about ->{
              Toast.makeText(this, "clicked about", Toast.LENGTH_SHORT).show()
              aboutFragment = AboutFragment()
              supportFragmentManager
                  .beginTransaction()
                  .replace(R.id.content_frame, aboutFragment)
                  .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                  .commit()
          } R.id.navi_photo ->{
          val intent = Intent(this, PhotoActivity:: class.java)
          startActivity(intent)
        }
      }
        drawer.closeDrawer(GravityCompat.START)
        return true
    }

    override fun onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START)
        }else
        super.onBackPressed()
    }
}


